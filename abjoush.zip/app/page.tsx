
import CoffeeWizard from "@/components/CoffeeWizard";
import { CoffeeShowcase } from "@/components/coffee-showcase";
import { Testimonials } from "@/components/testimonials";
import { AboutCoffee } from "@/components/about-coffee";
import { ReadMore } from "@/components/read-more";
import { CategoryFilter } from "@/components/category-filter";
import { FAQ } from "@/components/faq";
import { Tags } from "@/components/tags";
import { Header } from "@/components/header";
import { Footer } from "@/components/footer";

export default function Home() {
  return (
    <>
      <Header />
      <main className="min-h-screen w-full">
        <CoffeeWizard />
        <div className="w-full max-w-7xl mx-auto px-4 md:px-6 lg:px-8">
          <CategoryFilter />
          <CoffeeShowcase
            sectionId="products"
            title="پرفروش ترین ها"
            subtitle="قهوه‌ای برای هر سلیقه"
          />
          <CoffeeShowcase title="جدیدترین ها" subtitle="قهوه‌ای برای کشف کردن" />
          <CoffeeShowcase title="پیشنهاد ویژه" subtitle="قهوه‌ای برای علاقه‌مندان" />
          <CoffeeShowcase title="محبوب ترین ها" subtitle="قهوه‌ای برای هر سلیقه" />
          <Testimonials />
          <AboutCoffee />
          <ReadMore />
          <FAQ />
          <Tags />
        </div>
      </main>
      <Footer />
    </>
  );
}